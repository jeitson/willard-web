import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { AdviserRoutingModule } from './adviser-routing.module';


@NgModule({
  declarations: [],
  imports: [
    CommonModule,
    AdviserRoutingModule
  ]
})
export class AdviserModule { }
