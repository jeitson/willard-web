import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { CollectionCentersRoutingModule } from './collection-centers-routing.module';


@NgModule({
  declarations: [],
  imports: [
    CommonModule,
    CollectionCentersRoutingModule
  ]
})
export class CollectionCentersModule { }
