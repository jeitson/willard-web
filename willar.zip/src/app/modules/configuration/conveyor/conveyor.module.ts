import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { ConveyorRoutingModule } from './conveyor-routing.module';


@NgModule({
  declarations: [],
  imports: [
    CommonModule,
    ConveyorRoutingModule
  ]
})
export class ConveyorModule { }
