import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { PickuplocationRoutingModule } from './pickuplocation-routing.module';


@NgModule({
  declarations: [],
  imports: [
    CommonModule,
    PickuplocationRoutingModule
  ]
})
export class PickuplocationModule { }
