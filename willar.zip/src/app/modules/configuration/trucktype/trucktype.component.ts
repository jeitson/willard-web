import { Component } from '@angular/core';

@Component({
  selector: 'wlrd-trucktype',
  templateUrl: './trucktype.component.html',
  styleUrls: ['./trucktype.component.scss']
})
export class TrucktypeComponent {

}
