import { Component } from '@angular/core';

@Component({
  selector: 'wlrd-typecustomer',
  templateUrl: './typecustomer.component.html',
  styleUrls: ['./typecustomer.component.scss']
})
export class TypecustomerComponent {

}
