import { Component } from '@angular/core';

@Component({
  selector: 'wlrd-typedocuments',
  templateUrl: './typedocuments.component.html',
  styleUrls: ['./typedocuments.component.scss']
})
export class TypedocumentsComponent {

}
