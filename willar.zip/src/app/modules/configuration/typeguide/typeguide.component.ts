import { Component } from '@angular/core';

@Component({
  selector: 'wlrd-typeguide',
  templateUrl: './typeguide.component.html',
  styleUrls: ['./typeguide.component.scss']
})
export class TypeguideComponent {

}
