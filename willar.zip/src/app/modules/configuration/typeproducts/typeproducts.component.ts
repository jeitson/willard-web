import { Component } from '@angular/core';

@Component({
  selector: 'wlrd-typeproducts',
  templateUrl: './typeproducts.component.html',
  styleUrls: ['./typeproducts.component.scss']
})
export class TypeproductsComponent {

}
