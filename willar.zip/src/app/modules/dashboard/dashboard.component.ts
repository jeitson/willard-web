import { Component } from '@angular/core';

@Component({
  selector: 'wlrd-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.scss']
})
export class DashboardComponent {

}
