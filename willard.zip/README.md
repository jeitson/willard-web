# Intrucciones

examble icon en: `https://skote-v-light.angular.themesbrand.com`

navegar a la siguiente ruta: `https://skote-v-light.angular.themesbrand.com/icons/boxicons`
