import { Component } from '@angular/core';

@Component({
  selector: 'wlrd-city',
  templateUrl: './city.component.html',
  styleUrls: ['./city.component.scss']
})
export class CityComponent {

}
