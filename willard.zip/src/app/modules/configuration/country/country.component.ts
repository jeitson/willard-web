import { Component } from '@angular/core';

@Component({
  selector: 'wlrd-country',
  templateUrl: './country.component.html',
  styleUrls: ['./country.component.scss']
})
export class CountryComponent {

}
