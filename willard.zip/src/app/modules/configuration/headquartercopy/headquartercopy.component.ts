import { Component } from '@angular/core';

@Component({
  selector: 'wlrd-headquartercopy',
  templateUrl: './headquartercopy.component.html',
  styleUrls: ['./headquartercopy.component.scss']
})
export class HeadquartercopyComponent {

}
