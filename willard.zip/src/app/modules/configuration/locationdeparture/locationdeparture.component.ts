import { Component } from '@angular/core';

@Component({
  selector: 'wlrd-locationdeparture',
  templateUrl: './locationdeparture.component.html',
  styleUrls: ['./locationdeparture.component.scss']
})
export class LocationdepartureComponent {

}
