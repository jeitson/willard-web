import { Component } from '@angular/core';

@Component({
  selector: 'wlrd-routestatus',
  templateUrl: './routestatus.component.html',
  styleUrls: ['./routestatus.component.scss']
})
export class RoutestatusComponent {

}
