import { Component } from '@angular/core';

@Component({
  selector: 'wlrd-typeevidence',
  templateUrl: './typeevidence.component.html',
  styleUrls: ['./typeevidence.component.scss']
})
export class TypeevidenceComponent {

}
