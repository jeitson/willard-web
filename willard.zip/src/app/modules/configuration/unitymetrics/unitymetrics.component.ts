import { Component } from '@angular/core';

@Component({
  selector: 'wlrd-unitymetrics',
  templateUrl: './unitymetrics.component.html',
  styleUrls: ['./unitymetrics.component.scss']
})
export class UnitymetricsComponent {

}
