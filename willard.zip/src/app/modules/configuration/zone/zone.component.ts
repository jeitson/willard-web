import { Component } from '@angular/core';

@Component({
  selector: 'wlrd-zone',
  templateUrl: './zone.component.html',
  styleUrls: ['./zone.component.scss']
})
export class ZoneComponent {

}
