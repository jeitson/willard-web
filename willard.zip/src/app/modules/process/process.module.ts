import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { ProcessRoutingModule } from './process-routing.module';
import { FormsModule } from '@angular/forms';
import { RequestplannerComponent } from './requestplanner/requestplanner.component';
import { DetailrequestComponent } from './requestplanner/detailrequest/detailrequest.component';
import { RequestagencyComponent } from './requestagency/requestagency.component';
import { RequestlogisticsComponent } from './requestlogistics/requestlogistics.component';
import { ReceptionComponent } from './reception/reception.component';
import { ShippingComponent } from './shipping/shipping.component';
import { ConciliationComponent } from './conciliation/conciliation.component';
import { BulkrequestComponent } from './bulkrequest/bulkrequest.component';
import { ReporteComponent } from './reporte/reporte.component';
import { FacturaComponent } from './factura/factura.component';
import { CertificateInformationComponent } from './certificate-information/certificate-information.component';
import { FileUploadComponent } from './load/file-upload/file-upload.component';
import { ReportFileComponent } from './load/report-file/report-file.component';


@NgModule({
  declarations: [
    RequestplannerComponent,
    RequestagencyComponent,
    DetailrequestComponent,
    RequestlogisticsComponent,
    ReceptionComponent,
    ShippingComponent,
    ConciliationComponent,
    BulkrequestComponent,
    ReporteComponent,
    FacturaComponent,
    CertificateInformationComponent,
    FileUploadComponent,
    ReportFileComponent
  ],
  imports: [
    CommonModule,
    ProcessRoutingModule,
    FormsModule
  ]
})
export class ProcessModule { }
