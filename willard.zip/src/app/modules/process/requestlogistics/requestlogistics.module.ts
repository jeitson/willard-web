import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { RequestlogisticsRoutingModule } from './requestlogistics-routing.module';


@NgModule({
  declarations: [],
  imports: [
    CommonModule,
    RequestlogisticsRoutingModule
  ]
})
export class RequestlogisticsModule { }
