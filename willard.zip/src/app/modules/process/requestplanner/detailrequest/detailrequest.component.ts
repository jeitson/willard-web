import { Component } from '@angular/core';

@Component({
  selector: 'wlrd-detailrequest',
  templateUrl: './detailrequest.component.html',
  styleUrls: ['./detailrequest.component.scss']
})
export class DetailrequestComponent {

}
